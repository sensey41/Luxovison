// Page boutique temporaire
export default function ShopPage() { return <div className='text-white bg-black min-h-screen flex items-center justify-center text-4xl'>Boutique</div>; };