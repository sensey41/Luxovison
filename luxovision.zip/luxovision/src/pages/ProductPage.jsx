// Page produit temporaire
export default function ProductPage() { return <div className='text-white bg-black min-h-screen flex items-center justify-center text-4xl'>Page Produit</div>; };