// Page d'accueil temporaire
export default function HomePage() { return <div className='text-white bg-black min-h-screen flex items-center justify-center text-4xl'>Bienvenue sur Luxovision</div>; };